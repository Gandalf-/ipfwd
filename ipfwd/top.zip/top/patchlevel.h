#define PATCHLEVEL 5
#define BETA "beta12"
